import 'package:flutter/material.dart';

const pageBgColor = Color(0xFFFFF3E0);
const headBgColor = Color.fromARGB(255, 99, 62, 3);
const iconColor = Color.fromARGB(255, 214, 70, 2);

const headerH1 = TextStyle(fontSize: 25, fontWeight: FontWeight.bold);
